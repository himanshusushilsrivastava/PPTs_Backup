﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Windows.Forms;
using System.Drawing;
using System.Text;
using System.IO;
using System.Diagnostics;
using Sybase.Data.AseClient;
using System.Data.OleDb;

using System.Collections;



namespace Insert_Script_Generator
{
    public partial class Form1 : Form
    {

        string[] ipname = new string[40];
        public string strIPAddr;
        public string strIP;
        public string strPort;
        public string connectionstring;
        public Form1()
        {
            InitializeComponent();

        }

        private void Form1_Load(object sender, EventArgs e)
        {

            ddlEnvironment.Enabled = true;



            ddlEnvironment.Visible = true;
            env.Enabled = true;
            env.Visible = true;
            //tableName.Enabled = false;
           
            //ddldb.Enabled = false;

            tbuser.Enabled = false;
            tbPwd.Enabled = false;
            Authen.Enabled = false;
          
            dir.ClearSelected();
            inifile.ClearSelected();
            inifile.Visible = true;

            dir.Enabled = true;
            drive.Enabled = true;
            inifile.Enabled = true;
            file.Enabled = true;
            file.Visible = true;

            DirectoryInfo proDir1 = new DirectoryInfo("C:\\Sybase");
            if (proDir1.Exists)
            {

                drive.Drive = "C:";
                try
                {
                    dir.Path = "C:\\Sybase\\ini";

                    inifile.Path = "C:\\Sybase\\ini";
                }
                catch (Exception)
                {
                    MessageBox.Show("No correct path exists");
                }

                try
                {
                    inifile.FileName = "sql.ini";
                    file1();
                }
                catch (Exception)
                {
                    MessageBox.Show("Ini file not exists, please choose");
                }

            }

            else
            {
                MessageBox.Show("Please select the path of sql ini file to fetch the environment details", "Message");
            }
        }

      


        public void file1()
        {
            string filep;
            try
            {
                filep = inifile.Path.ToString() + @"\" + inifile.SelectedItem.ToString();

                try
                {


                    string strServerIP = string.Empty;
                    string strServerName = string.Empty;

                    StreamReader srd = new StreamReader(filep);
                    DataRow dr;
                    System.Data.DataTable dtServer = new System.Data.DataTable();
                    dtServer.Columns.Add("ServerName");
                    dtServer.Columns.Add("ServerIP");
                    dtServer.AcceptChanges();

                    int i = 0;
                    while (!srd.EndOfStream)
                    {

                        string strline;
                        strline = srd.ReadLine();
                        if (strline.Contains("["))
                        {
                            strServerName = strline.Substring(strline.IndexOf("[") + 1, strline.IndexOf("]") - 1).ToString();
                        }
                        if (strline.Contains("query=TCP,"))
                        {
                            ipname[i] = strline.Substring(strline.IndexOf("P") + 2, strline.Length - strline.IndexOf("P") - 2).ToString();
                            strServerIP = ipname[i].ToString();
                            i = i + 1;
                        }
                        if (strServerIP.Length != 0)
                        {
                            dr = dtServer.Rows.Add();
                            dr["ServerName"] = strServerName;
                            dr["ServerIP"] = strServerIP;
                            dtServer.AcceptChanges();
                            strServerIP = "";
                        }
                    }


                    ddlEnvironment.DataSource = dtServer;
                    ddlEnvironment.DisplayMember = "ServerName";
                    ddlEnvironment.ValueMember = "ServerIP";
                    ddlEnvironment.SelectedIndex = 0;
                }

                catch (Exception)
                {
                    MessageBox.Show("An Error Occured while Processiong !", "ErrorMessage");
                   this.Dispose();
                }

                ddlEnvironment.Enabled = true;
                env.Enabled = true;
                env.Visible = true;
                ddlEnvironment.Visible = true;
                tbuser.Enabled = true;
                tbPwd.Enabled = true;
                Authen.Enabled = true;
                dir.Enabled = true;
                drive.Enabled = true;
                inifile.Enabled = true;
            }
            catch (Exception)
            {
                MessageBox.Show("no valid ini file found please select correct one");
                inifile.Focus();
            }
        }

        public void Form_Close()
        {

   
                this.Close();
        

        }

        public void DBConnect()
        {
            strIPAddr = ddlEnvironment.SelectedValue.ToString();
            strIP = strIPAddr.Substring(0, strIPAddr.IndexOf(","));
            //ddldb.Items.Clear();
       

            strPort = strIPAddr.Substring(strIPAddr.IndexOf(",") + 1, strIPAddr.Length - strIPAddr.IndexOf(",") - 1);
            try
            {

                Sybase.Data.AseClient.AseConnection SqlCon = new Sybase.Data.AseClient.AseConnection
                    ("server=" + strIP + "; Port=" + strPort + ";uid=" + tbuser.Text.Trim() + ";pwd=" + tbPwd.Text.Trim() );
                connectionstring = SqlCon.ConnectionString;
                //MessageBox.Show(SqlCon.ConnectionString, "Database Connected");
                SqlCon.Open();
                //MessageBox.Show("Authenticated", "Message");
               // Sybase.Data.AseClient.AseCommand SqlCom = new Sybase.Data.AseClient.AseCommand();
                //SqlCom.Connection = SqlCon;
                //SqlCom.CommandType = CommandType.StoredProcedure;
                //SqlCom.CommandText = "sp_databases";
                //Sybase.Data.AseClient.AseDataReader SqlDR;
                //SqlDR = SqlCom.ExecuteReader();

                //Sybase.Data.AseClient.AseConnection SqlCon1 = new Sybase.Data.AseClient.AseConnection(connectionstring + ";Database=fakpfstage");
                //SqlCon1.Open();
                //Sybase.Data.AseClient.AseDataReader ase;
                //string cmdstr = "select distinct name from sysobjects where type = 'U' order by name";
                //Sybase.Data.AseClient.AseCommand cmd = new AseCommand(cmdstr, SqlCon1);
                //ase = cmd.ExecuteReader();


                //while (ase.Read())
                //{                    
                    //cddb.Items.Add(ase.GetString(0));                    
                //}

                DialogResult result1 = MessageBox.Show("Click OK to Proceed !", "Authenticated", MessageBoxButtons.OKCancel);
                if (result1 == DialogResult.OK)
                {

                    mainform.sybasestring = connectionstring;
                    mainform.Show();
                    this.Hide();

                }

                else
                {
                    MessageBox.Show("Please enter the Username and Password", "Error Message");
                    tbuser.Clear();
                    tbPwd.Clear();

                }
                //ddldb.Enabled = true;
         
                //tableName.Enabled = true;
               
                Authen.Enabled = true;
                Exit.Enabled = true;
              
            }
            catch (Exception Ex)
            {
                if (Ex.Message.ToString().IndexOf("Login failed") == 0)
                {
                    MessageBox.Show("Login Failed for the Given Username & Password", "Error Message");
                 
                }
                else
                {
                    MessageBox.Show("An Error Occured While Executing:" + Ex, "Error Message");
                    this.Dispose();
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (tbPwd.Text.Trim().Length > 0 && tbuser.Text.Trim().Length > 0)
            {

            //    DBConnect();

                
                OleDbConnection oraclecon = new OleDbConnection();

                oraclecon.ConnectionString = "Driver={Microsoft ODBC for Oracle};" +
                                             "DataSource= (DESCRIPTION = (ADDRESS_LIST = (ADDRESS = (PROTOCOL = TCP)(HOST = dbsp8021.uhc.com)(PORT = 1521)))(CONNECT_DATA =(SID = ufadv1)(SERVER = DEDICATED));" + "User Id=" + tbuser.Text.Trim() + ";Password=" + tbPwd.Text.Trim() + ";";
                oraclecon.Open();

            }

            else
            {
                MessageBox.Show("Please enter the Username and Password", "Error Message");
            }

        }

        

        private void DirectoryInfo(string p)
        {
            throw new NotImplementedException();
        }

        private void driveSelect_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                dir.Path = drive.Drive;
            }
            catch (Exception)
            {

                    MessageBox.Show("An Error Occured While Executing: Drive Unavailable" , "Error Message");
            }

        }

        private void dirSelect_SelectedIndexChanged(object sender, EventArgs e)
        {

            inifile.Path = dir.Path;
            inifile.Pattern = "*.ini";
            inifile.Visible = true;
            file.Enabled = true;
            file.Visible = true;

        }



 
        private void save_Click(object sender, EventArgs e)
        {

        }

        private void fileSelect_SelectedIndexChanged(object sender, EventArgs e)
        {
            string filep;
            try
            {
                filep = inifile.Path.ToString() + @"\" + inifile.SelectedItem.ToString();

               try
             {


                    string strServerIP = string.Empty;
                    string strServerName = string.Empty;

                    StreamReader srd = new StreamReader(filep);
                    DataRow dr;
                    System.Data.DataTable dtServer = new System.Data.DataTable();
                    dtServer.Columns.Add("ServerName");
                    dtServer.Columns.Add("ServerIP");
                    dtServer.AcceptChanges();

                    int i = 0;
                    while (!srd.EndOfStream)
                    {

                        string strline;
                        strline = srd.ReadLine();
                        if (strline.Contains("["))
                        {
                            strServerName = strline.Substring(strline.IndexOf("[") + 1, strline.IndexOf("]") - 1).ToString();
                        }
                        if (strline.Contains("query=TCP,"))
                        {
                            ipname[i] = strline.Substring(strline.IndexOf("P") + 2, strline.Length - strline.IndexOf("P") - 2).ToString();
                            strServerIP = ipname[i].ToString();
                            i = i + 1;
                        }
                        if (strServerIP.Length != 0)
                        {
                            dr = dtServer.Rows.Add();
                            dr["ServerName"] = strServerName;
                            dr["ServerIP"] = strServerIP;
                            dtServer.AcceptChanges();
                            strServerIP = "";
                        }
                    }


                    ddlEnvironment.DataSource = dtServer;
                    ddlEnvironment.DisplayMember = "ServerName";
                    ddlEnvironment.ValueMember = "ServerIP";
                    ddlEnvironment.SelectedIndex = 0;

             }
               catch (Exception)
                {
                    MessageBox.Show("An Error Occured while Processiong !", "ErrorMessage");
                    this.Dispose();
                }

                ddlEnvironment.Enabled = true;
                env.Enabled = true;
                env.Visible = true;
                ddlEnvironment.Visible = true;

                tbuser.Enabled = true;
                tbPwd.Enabled = true;
                Authen.Enabled = true;
                dir.Enabled = false;
                drive.Enabled = false;
                inifile.Enabled = false;
            }

            catch (Exception)
            {
                MessageBox.Show("No valid ini file found!Please select correct one");
            }

        }


        private void ddlEnvironment_SelectedIndexChanged(object sender, EventArgs e)
        {
            //tbuser.Clear();
            //tbPwd.Clear();
            tbuser.Focus();

        }

      
      

        private void text_TextChanged(object sender, EventArgs e)
        {

        }

        private void Authen_Click(object sender, EventArgs e)
        {
            if (tbPwd.Text.Trim().Length > 0 && tbuser.Text.Trim().Length > 0)
            {

               // DBConnect();

                OleDbConnection oraclecon = new OleDbConnection();

                oraclecon.ConnectionString = "Driver=MSDAORA;" +
                                             "DataSource= (DESCRIPTION = (ADDRESS_LIST = (ADDRESS = (PROTOCOL = TCP)(HOST = dbsp8021.uhc.com)(PORT = 1521)))(CONNECT_DATA =(SID = ufadv1)(SERVER = DEDICATED));" + "User Id=" + tbuser.Text.Trim() + ";Password=" + tbPwd.Text.Trim() + ";";
                oraclecon.Open();
            }

            else
            {
                MessageBox.Show("Please enter the Username and Password", "Error Message");
            }
        }

        Form2 mainform = new Form2();

        private void Exit_Click(object sender, EventArgs e)
        {
            DialogResult result1 = MessageBox.Show("Are you sure you wants to Exit?", "Prompt Message", MessageBoxButtons.YesNo);
            if (result1 == DialogResult.Yes)
            {
                Application.Exit();

            }

        }

        private void cddb_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

    }
}
