﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Windows.Forms;
using System.Drawing;
using System.Text;
using System.IO;
using System.Diagnostics;
using Sybase.Data.AseClient;
using System.Data.OleDb;
using System.Reflection;
using System.IO.Compression;
using Microsoft.Office.Interop.Excel;
using System.Collections;
using System.DirectoryServices.AccountManagement;
using System.Net.Mail;


using Excel = Microsoft.Office.Interop.Excel;
using Outlook = Microsoft.Office.Interop.Outlook;
namespace Insert_Script_Generator
{
    public partial class Form2 : Form
    {
        List<int> duprowno = new List<int>();
        string[] ipname = new string[50];
        string[] deletecolumn = new string[110];        
        string[] exponentialcolumns= new string[110];
        string[] timecolumns = new string[100];
        string[] datetimecolumns = new string[100];

        public string strIPAddr;
        public string strIP;
        public string strPort;
        public string invalidcolumnname;
        public string invalidcolumns;
        public int vertical;
        public int horizontal;
        public string blanks = "";
        public Array myValues;
        public string checkstring = "";
        public int flag = 0;
        public int sysdate = 0;
        public string filepath;
        public int sheetno;
        public string sheetname = "";
        public string databasestring="";
        public string s1 = "";
        public string sybasestring { get; set; }
        public string field_names = "";
        public string currentdate;
        public int sheet_count = 0;
        public int datecolumn = 0;
        public int duplicaterecords = 0;
        public string delete_column = "";
        public string attachment = "";
        public string attachment1 = "";
        public string attachment2 = "";
        public string currdate = "";
        //public int importtime = 0;
        public double importtime = 0;
        public double generatetime = 0;
        public double updtime = 0;
      public Form2()
        {
            InitializeComponent();
            
            Import.Enabled = false;
            script.Enabled = false;
            button3.Enabled = false;
            
            lblprocessstatus.Width = 1500;
            lblprocessstatus.Spring = true;
            lblprocessstatus.Text = "";
            toolStripProgressBar2.Visible = false;
          
        }
 




       private void Form2_Load(object sender, EventArgs e)
                {
                    currentdate = DateTime.Now.ToString("MM/dd/yyyy");
            cddb.Enabled = false;
            ccb.Enabled = false;
           // MessageBox.Show(sybasestring);
            //For database values
            Sybase.Data.AseClient.AseConnection SqlCon = new Sybase.Data.AseClient.AseConnection
            (sybasestring);
            SqlCon.Open();
            Sybase.Data.AseClient.AseCommand SqlCom = new Sybase.Data.AseClient.AseCommand();
            SqlCom.Connection = SqlCon;
            SqlCom.CommandType = CommandType.StoredProcedure;
            SqlCom.CommandText = "sp_databases";
            Sybase.Data.AseClient.AseDataReader SqlDR;
            SqlDR = SqlCom.ExecuteReader();
           
            cddb.Items.Clear();
            //cddb.Text = "--------------------Select Database--------------------";
            while (SqlDR.Read())
            {
                //ddldb.Items.Add(SqlDR.GetString(0));
                cddb.Items.Add(SqlDR.GetString(0));
                string x = Convert.ToString(SqlDR.GetString(0));
                //MessageBox.Show(x);
            }

           //ddldb.Enabled = true;

                    //tableName.Enabled = true;


        }
       private void cddb_SelectedIndexChanged_1(object sender, EventArgs e)

       {
           try
           {
               Sybase.Data.AseClient.AseConnection SqlCon1 = new Sybase.Data.AseClient.AseConnection
                   (sybasestring + ";Database=" + cddb.SelectedItem.ToString());
               databasestring = SqlCon1.ConnectionString;
               //MessageBox.Show(databasestring);
               SqlCon1.Open();
               Sybase.Data.AseClient.AseDataReader ase;
               string cmdstr = "select distinct name from sysobjects where type = 'U' order by name";
               Sybase.Data.AseClient.AseCommand cmd = new AseCommand(cmdstr, SqlCon1);
               ase = cmd.ExecuteReader();
               ccb.Enabled = true;
               ccb.Items.Clear();
               ccb.Text = "---------------Select Table Name---------------";

               // write each record
               while (ase.Read())
               {
                   ccb.Items.Add(ase["name"]);
                   ccb.MaxDropDownItems = 14;
               }

               SqlCon1.Close();

           }
           catch (Exception Ex)
           {
               MessageBox.Show("Access denied to selected database, please select another database");
           }

       }

        public void Form_Close()
        {

            DialogResult result1 = MessageBox.Show("Do you wish to continue generating script for other tables?", "Prompt Message", MessageBoxButtons.YesNo);
            if (result1 == DialogResult.Yes)
            {
             MessageBox.Show("Please select the Input File", "Message");
             checkBox3.Enabled = false;
             checkBox2.Enabled = false;
             checkBox1.Enabled = false;
             toolStripProgressBar2.Visible = false;
             lblstatus.Text = "Ready";
             lblprocessstatus.Text = "     ";
             lbltotal.Text = "     ";
             lblduplicate.Text = "     ";
             lbloriginal.Text = "     ";
             lblcolumns.Text = "     ";
             lbltime.Text = "     ";
             Import.Enabled = false;
             txtfilepath.Clear();
             txtfilepath.Text = "Please Select an Input file";
             GridView1.DataSource = null;
             Import.Text = "Import Data";
             script.Enabled = false;
             button3.Enabled = false;
             comboBox1.Items.Clear();
             ccb.Items.Clear();
             comboBox1.Text = "";
             ccb.Text = "";
             cddb.Text = "";
             comboBox1.Enabled = false;
             cddb.Enabled = false;
             ccb.Enabled = false;
             s1 = "";
            
            }

            else
            {
                this.Close();
                Form1 loginform = new Form1();
                loginform.Show();
                
           
            }

        }

        private void DirectoryInfo(string p)
        {
            throw new NotImplementedException();
        }





        private void text_TextChanged(object sender, EventArgs e)
        {

        }

        private void Import_Click(object sender, EventArgs e)
        {
            toolStripProgressBar2.Visible = true;
            toolStripProgressBar2.Value = 0;
            lblstatus.Text = "Ready";
            lblprocessstatus.Text = "     ";
            lbltotal.Text = "     ";
            lblduplicate.Text = "     ";
            lbloriginal.Text = "     ";
            lblcolumns.Text = "     ";
            lbltime.Text = "     ";
            ImportData();
        }




        public void ImportData()
        {
            invalidcolumns = "";
            lblstatus.Text = "Wait";
            Stopwatch sw = Stopwatch.StartNew();
            currdate = DateTime.Now.ToString("MMddyyyyHHmmss");//Current Date and Month  
            button3.Enabled = false;
            checkBox1.Enabled = false;
            checkBox2.Enabled = false;
            script.Enabled = false;
            checkstring = "";
            
            if ((filepath.Contains("xlsx")) || (filepath.Contains("xls")) || (filepath.Contains("csv")))
            {               
                try
                {
                    s1 = ccb.SelectedItem.ToString();
                }
                catch (Exception)
                {
                    //MessageBox.Show("Please Select a Table", " Error Message");
                }
                if (sheetno > 0)
                {
                    Excel.Application xlApp;
                    Excel.Workbook xlWorkBook;
                    Excel.Worksheet xlWorkSheet;
                    var missing = System.Reflection.Missing.Value;
                    object Missing = System.Type.Missing;
                    
                    xlApp = new Excel.Application();                    
                    xlWorkBook = xlApp.Workbooks.Open(filepath, false, true, missing, missing, missing, true, Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, '\t', false, false, 0, false, true, 0);
                    xlWorkSheet = (Microsoft.Office.Interop.Excel.Worksheet)xlWorkBook.Worksheets.get_Item(sheetno);
                    Excel.Range xlRange = xlWorkSheet.UsedRange;
                    vertical = xlRange.Rows.Count;
                    horizontal = xlRange.Columns.Count;
                    myValues = (Array)xlRange.get_Value(Excel.XlRangeValueDataType.xlRangeValueDefault);
                    System.Data.DataTable dt = new System.Data.DataTable();

                    toolStripProgressBar2.Value = 20;
                    if (!(cddb.Text == "---------Select Database---------"))
                    {
                        toolStripProgressBar2.Value = 40;

                        if (s1.Length > 0)
                        {
                            // get header information
                            try
                            {
                                int Index10011;
                                Index10011 = filepath.LastIndexOf("\\");
                                lblprocessstatus.Text = "Opening Input File : " + filepath.Substring((Index10011 + 1), ((filepath.Length) - Index10011 - 1));
                                toolStripProgressBar2.Value = 50;
                                // get header information
                                //***************************************
                                Sybase.Data.AseClient.AseConnection SqlCon3 = new Sybase.Data.AseClient.AseConnection
                                (databasestring);
                                 SqlCon3.Open();
                                for (int i = 1; i <= horizontal; i++)
                                {

                                    string[] columnname = { (string)(xlRange.Cells[1, i] as Excel.Range).Value2 };
                                 foreach (string columns in columnname)
                                 {
                                     //a = +i;
                                     sysdate = sysdate + 1;
                                     toolStripProgressBar2.Value = 60;

                                     lblprocessstatus.Text = "Checking Data Type : " + columns;
                                    invalidcolumnname = columns;
                                    //MessageBox.Show(columns);

                                    string cmdstr = "select t.name from sysobjects o inner join syscolumns c on c.id = o.id inner join systypes t on t.type = c.type where o.type = 'U' and o.name = '" + s1 + "' and t.name not in ('sysname', 'nid', 'uid', 'nvarchar', 'tid', 'nchar','longsysname') and c.name = '" + columns + "'";
                                    Sybase.Data.AseClient.AseCommand cmd = new AseCommand(cmdstr, SqlCon3);
                                    string datatype = (string)cmd.ExecuteScalar();
                                    try
                                    {
                                       
                                        //MessageBox.Show (datatype,columns);
                                        if (columns.Contains("LAST_UPD_DTM") || columns.Contains("LAST_UPD_USUS_ID") || columns.Contains("UPD_USER_ID"))
                                        {
                                            if (columns.Contains("LAST_UPD_DTM"))
                                            {
                                                if (!(Convert.ToString((xlRange.Cells[2, sysdate] as Excel.Range).Value2) == "GETDATE()"))
                                                {
                                                    checkstring += "N";
                                                }
                                                else
                                                {
                                                    checkstring += "Y";
                                                }
                                            }
                                            if (columns.Contains("LAST_UPD_USUS_ID") || columns.Contains("UPD_USER_ID"))
                                            {
                                                checkstring += "Y";
                                            }
                                            
                                        }

                                        else if (datatype == "int" || datatype == "money" || datatype == "moneyn" || datatype == "MONEY" || datatype == "float" || datatype == "usmallint" || datatype == "varbinary" || datatype == "bigint" || datatype == "binary" || datatype == "bit" || datatype == "decimal" || datatype == "decimaln" || datatype == "floatn" || datatype == "intn" || datatype == "numeric" || datatype == "numericn" || datatype == "real" || datatype == "smallint" || datatype == "smallmoney" || datatype == "tinyint" || datatype == "ubigint" || datatype == "uint" || datatype == "uintn" || datatype == "usmallint" || datatype == "char" || datatype == "varchar" || datatype == "datetime")
                                        {

                                            if (datatype == "int" || datatype == "money" || datatype == "moneyn" || datatype == "MONEY" || datatype == "float" || datatype == "usmallint" || datatype == "varbinary"|| datatype == "bigint" || datatype == "binary" || datatype == "bit" || datatype == "decimal" || datatype == "decimaln" || datatype == "floatn" || datatype == "intn" || datatype == "numeric" || datatype == "numericn" || datatype == "real" || datatype == "smallint" || datatype == "smallmoney" || datatype == "tinyint" || datatype == "ubigint" || datatype == "uint" || datatype == "uintn" || datatype == "usmallint")
                                            {
                                                checkstring += "Y";

                                            }
                                            if (datatype == "char" || datatype == "varchar" || datatype == "datetime")
                                            {
                                                checkstring += "N";
                                            }

                                        }

                                        else if (datatype == null)
                                        {
                                            invalidcolumns += "'" + invalidcolumnname + "',";

                                            flag += 1;
                                        }
                                        else
                                        {
                                            checkstring += "N";

                                        }
                                       
                                    }
                                    catch (Exception Ex)
                                    {
                                        MessageBox.Show(Ex.Message, "Remove Null Columns from Sheet");
                                        script.Enabled = false;
                                    }
                                    
                                    System.Threading.Thread.Sleep(25);
                                }

                            }

                                toolStripProgressBar2.Value = 80;
                                SqlCon3.Close();

                                xlWorkBook.Close(true, missing, missing);
                                xlApp.Quit();

                                // Get the row information
                                try
                                {
                                    String constr = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" +
                                                    filepath +
                                                    ";Extended Properties='Excel 12.0 XML;HDR=YES;IMEX=1';";

                                    OleDbConnection con = new OleDbConnection(constr);
                                    OleDbCommand oconn = new OleDbCommand("Select * From [" + sheetname + "$]", con);
                                    con.Open();

                                    OleDbDataAdapter sda = new OleDbDataAdapter(oconn);
                                    System.Data.DataTable data = new System.Data.DataTable();
                                    sda.FillSchema(data, SchemaType.Source);
                                    sda.Fill(data);
                                    con.Close();
                                    GridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
                                    GridView1.DataSource = data.DefaultView;
                                    for (int i = 0; i < GridView1.Columns.Count; i++)
                                    {
                                       //MessageBox.Show(GridView1.Columns[i].ValueType.ToString());
                                        if (GridView1.Columns[i].ValueType == typeof(double))
                                        {

                                            
                                            //string exponentialcolumn = GridView1.Columns[i].HeaderText;
                                            string exponentialcolumnvalue =GridView1.Rows[1].Cells[i].Value.ToString();
                                            
                                            if(exponentialcolumnvalue.Contains("E+")||exponentialcolumnvalue.Contains("e+"))
                                            {
                                                //MessageBox.Show(exponentialcolumnvalue);
                                              exponentialcolumns[i] = GridView1.Columns[i].HeaderText;
                                                GridView1.Columns[i].DefaultCellStyle.Format = "F0";
                                            }
                                            else
                                            {
                                                GridView1.Columns[i].ValueType = typeof(string);

                                            }
                                        }
                                        //MessageBox.Show(GridView1.Columns[i].ValueType.ToString());
                                        if (GridView1.Columns[i].ValueType == typeof(DateTime))
                                        {


                                            //string exponentialcolumn = GridView1.Columns[i].HeaderText;
                                            string timecolumnvalue = GridView1.Rows[1].Cells[i].Value.ToString();

                                            if (timecolumnvalue.Contains("1899"))
                                            {
                                                //MessageBox.Show(timecolumnvalue);
                                                timecolumns[i] = GridView1.Columns[i].HeaderText;
                                                GridView1.Columns[i].DefaultCellStyle.Format = "T";
                                            }
                                            else
                                            {
                                                    datetimecolumns[i] = GridView1.Columns[i].HeaderText;
                                                    GridView1.Columns[i].DefaultCellStyle.Format = "d";

                                            }
                                        }

                                    }

                                }
                                catch (Exception Ex)
                                {
                                    MessageBox.Show(Ex.Message, "Connection Lost");
                                }
                            }
                            catch (Exception Ex)
                            {
                                MessageBox.Show(Ex.Message, "Connection Lost");
                            }

                            for (int i = 0; i < GridView1.Rows.Count; i++)
                            {
                                DataGridViewRowHeaderCell cell = GridView1.Rows[i].HeaderCell;
                                cell.Value = (i + 1).ToString();
                                GridView1.Rows[i].HeaderCell = cell;
                            }
                            toolStripProgressBar2.Value = 100;
                            GridView1.AutoResizeRowHeadersWidth(DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders);

                            if (flag == 0)
                            {
                                script.Enabled = true;
                            }
                            else
                            {
                                Import.Text = "Refresh_Data";
                                DATAError();

                            }
                            for (int i = 1; i < GridView1.RowCount; i++)
                            {
                                if ((GridView1.Rows[i].Cells[0].Value.ToString() == "") && (GridView1.Rows[i].Cells[1].Value.ToString() == ""))
                                {
                                    GridView1.Rows.RemoveAt(i);
                                    i--;
                                }
                            }
                            GridView1.AllowUserToAddRows = false;
                            Import.Text = "Refresh_Data";
                            //xlApp.Quit();
                            //Checking for LAST_UPD_DTM and LAST_UPD_USUS_ID columns
                            columncheck();
                            setRowNumber();
                            toolStripProgressBar2.Visible = false;
                            lblstatus.Text = "Ready";
                            lblprocessstatus.Text = "Records Imported Sucessfully !";                            
                            lbltotal.Text = "Total Records : "+GridView1.RowCount.ToString();
                            lblduplicate.Text = "Duplicate Records : " + duplicaterecords.ToString();
                            lbloriginal.Text = "Original Records : " + (GridView1.RowCount - duplicaterecords).ToString();
                            lblcolumns.Text = GridView1.ColumnCount.ToString()+ " Columns";
                            int Index100;
                            Index100 = filepath.LastIndexOf("\\");
                            //lblfilename.Text= "File Name : "+filepath.Substring((Index100 + 1), ((filepath.Length) - Index100 - 1));
                            sw.Stop();
                            lbltime.Text = "Time Consumed : " + sw.Elapsed.TotalSeconds + "sec.";
                            ///importtime =Convert.ToInt32(sw.Elapsed.TotalSeconds);
                            importtime = Convert.ToDouble(sw.Elapsed.TotalSeconds);
                          
                        }
                        else
                        {
                            MessageBox.Show("Please Select a Valid Table Name", "Error Message");
                            ccb.Focus();
                        }
                    
                      }
                        else
                          {
                          MessageBox.Show("Please select a Valid Database", "Error Message");
         
                         }
                     }
                    else
                    {
                        MessageBox.Show("Please Select a Valid WorkSheet", "Error Message");
                        comboBox1.Focus();

                    }
                

            }
            else
            {
                MessageBox.Show("Please select a Valid Input File", "Error Message");
         
            }

        }

        private void columncheck()
        {

            int i = 0;
            datecolumn = 0;
            int b = 0;
            int flaga = 0;
            int flagb = 0;

            field_names = "(";
            foreach (DataGridViewColumn col in GridView1.Columns)
            {
                field_names += col.HeaderText + ",";

            }
            field_names = field_names.Remove(field_names.Length - 1);
            field_names += ")";  

            foreach (DataGridViewColumn col in GridView1.Columns)
            {
                //MessageBox.Show(col.HeaderText);
                //  MessageBox.Show(delete_column);

                if (col.HeaderText.Contains("LAST_UPD_DTM"))
                {
                    datecolumn = i;
                    flaga = 1;
                }

                if (col.HeaderText.Contains("LAST_UPD_USUS_ID") || col.HeaderText.Contains("UPD_USER_ID"))
                 {
                     
                     b = i;
                     flagb = 1;
                 }
                 i++;
            }

            if (flaga == 1)
            {
                string getdate = DateTime.Now.ToString("MM/dd/yyyy");
                for (int c = 0; c < GridView1.Rows.Count; c++)
                {
                    string check = GridView1.Rows[c].Cells[datecolumn].Value.ToString();
                    string types = GridView1.Columns[datecolumn].ValueType.ToString();
                    if ((check == "") && !(types == "System.DateTime"))
                  {                  
                      GridView1.Rows[c].Cells[datecolumn].Value = "GETDATE()";
                  }
                    if ((check == "") && (types == "System.DateTime"))
                    {
                        GridView1.Rows[c].Cells[datecolumn].Value = getdate;                        
                    }

                }
            }
            if (flagb == 1)
            {
                //MessageBox.Show(datecolumn.ToString());
                for (int c = 0; c < GridView1.Rows.Count; c++)
                {
                    string check = GridView1.Rows[c].Cells[b].Value.ToString();
                    string types = GridView1.Columns[b].ValueType.ToString();
                    //MessageBox.Show(check);
                    if (!(check == "SUSER_NAME()"))
                    {
                    if ((check == "")&& !(types == "System.DateTime"))
                    {
                        GridView1.Rows[c].Cells[b].Value = "SUSER_NAME()";
                    }
                    if (!(check == "") && !(types == "System.DateTime"))
                    {
                        GridView1.Rows[c].Cells[b].Value = "\"" + GridView1.Rows[c].Cells[b].Value + "\"";
                     
                    }

                    }
                }
            }
            
        }

        private void setRowNumber()
        {
            duprowno.Clear();
            duplicaterecords = 0;

            for (int currentRow = 0; currentRow < GridView1.Rows.Count - 1; currentRow++)
            {
                DataGridViewRow rowToCompare = GridView1.Rows[currentRow];

                for (int otherRow = currentRow + 1; otherRow < GridView1.Rows.Count; otherRow++)
                {
                    DataGridViewRow row = GridView1.Rows[otherRow];

                    bool duplicateRow = true;

                    for (int cellIndex = 0; cellIndex < row.Cells.Count; cellIndex++)
                    {
                        if (!rowToCompare.Cells[cellIndex].Value.Equals(row.Cells[cellIndex].Value))
                        {
                            duplicateRow = false;
                            break;
                        }
                    }

                    if (duplicateRow)
                    {
                        rowToCompare.DefaultCellStyle.BackColor = Color.Yellow;
                        row.DefaultCellStyle.BackColor = Color.Orange;
                        //GridView1.Rows[currentRow].DefaultCellStyle.BackColor = Color.Yellow;
                        //GridView1.Rows[otherRow].DefaultCellStyle.BackColor = Color.Orange; 

                        
                        
                    }
                }
            }

            for (int i = 0; i < GridView1.Rows.Count; i++)
            {

                string a = GridView1.Rows[i].DefaultCellStyle.BackColor.ToString();

                if ((a == "Color[Yellow]") || (a == "Color [Yellow]"))
                {
                    duprowno.Add(i);
                    duplicaterecords += 1;


                }
            }
            if (duplicaterecords > 0)
            {
                checkBox1.Enabled = true;
                checkBox3.Enabled = true;
                script.Enabled = false;
                Import.Text = "Refresh_Data";
            }
        }

        public void DATAError()
        {
            invalidcolumns = invalidcolumns.Remove(invalidcolumns.Length - 1);
            
            MessageBox.Show("Column " + invalidcolumns + " not found in " + s1, " Please remove extra columns from sheet", MessageBoxButtons.OK, MessageBoxIcon.Error);
            script.Enabled = false;
          
            checkBox2.Enabled = true;
            
            checkBox2.Focus();
            delete_column = invalidcolumns;
            //invalidcolumns = "";
            flag = 0;

        }

        private void script_Click(object sender, EventArgs e)
        {
            checkBox3.Enabled = false;
            lblstatus.Text = "Wait";
            lblprocessstatus.Text = "Generating Insert Script !";
            lbltime.Text = "";
            Stopwatch sw = Stopwatch.StartNew();
            int Index100;
            Index100 = filepath.LastIndexOf("\\");
            string filename = filepath.Substring((Index100 + 1), ((filepath.Length) - Index100 - 1));
            
            if (!Directory.Exists(@"C:\" + "Insert_Scripts\\"+s1+currdate))
            {
                Directory.CreateDirectory(@"C:\" + "Insert_Scripts\\" + s1 + currdate);
            }
            string path = @"c:\\Insert_Scripts\\" + s1 + currdate + "\\" + s1 + "_insert" + ".sql";
            FileStream fs = null;
            if (!File.Exists(path))
            {
                using (fs = File.Create(path))
                {

                }
            }
            attachment = path;
            File.WriteAllText(path, "");                
            using (System.IO.StreamWriter file = new System.IO.StreamWriter((path), true))
            {   file.WriteLine("/******************************************************************************");
                string newline = "";
                newline =" * This script file loads the data into table "+s1+"*";
               if(newline.Length < 80)
                {
                    newline = newline.Remove(newline.Length - 1);
                    
                }

                while (newline.Length < 80)
                {
                    newline += " ";
                }
                newline= newline.Remove(newline.Length - 2);
                newline += "*";
                file.WriteLine(newline);
                file.WriteLine(" ******************************************************************************/");
                file.WriteLine("/******************************************************************************");
                string scriptname = "";
                scriptname = " ** Insert Script Name      : " + s1 + "_insert" + "*";
                if(scriptname.Length < 80)
                {
                    scriptname = scriptname.Remove(scriptname.Length - 1);
                    
                }

                while (scriptname.Length < 80)
                {
                    scriptname += " ";
                }
                scriptname = scriptname.Remove(scriptname.Length - 2);
                scriptname += "*";
                file.WriteLine(scriptname);
                file.WriteLine(" ** Purpose                 : Insert script to load data into table           *");               
                  scriptname = " **                           "+ s1 + "*";
                if (scriptname.Length < 80)
                {
                    scriptname = scriptname.Remove(scriptname.Length - 1);

                }

                while (scriptname.Length < 80)
                {
                    scriptname += " ";
                }
                scriptname = scriptname.Remove(scriptname.Length - 2);
                scriptname += "*";
                file.WriteLine(scriptname);                
                file.WriteLine(" ** Revision History        : 1.0 - "+currentdate +" UHGIS                          *");
                file.WriteLine(" **                           Initial version                                 *");
                file.WriteLine(" **                                                                           *");
                file.WriteLine(" ** Autogenerated Script by Insert Script Generator Tool                      *");
                file.WriteLine("*******************************************************************************/");
                file.WriteLine("PRINT 'START : Inserting into table " + s1 + "'");
                file.WriteLine("GO");
            }
            //toolStripProgressBar2.Value = 40;
            int check = 0;
            for (int a = 0; a < GridView1.Rows.Count; a++)
            {
                DataGridViewRow row = GridView1.Rows[a];
                
                object[] poop = new object[row.Cells.Count];


                for (int c = 0,b = 1;c< row.Cells.Count && b <= row.Cells.Count;c++,b++)
                {

                  try
                   {
                        int flag = 0;
                        int flaga = 0;
                        int flagb = 0;
                        foreach (string expcolumn in exponentialcolumns)
                        {
                            
                            if ((GridView1.Columns[c].HeaderText == expcolumn))
                            {
                                
                                flag = 1;
                            }
                        }
                        foreach (string timecolumn in timecolumns)
                        {

                            if ((GridView1.Columns[c].HeaderText == timecolumn))
                            {

                                flaga = 1;
                            }
                        }
                        foreach (string datetimecolumn in datetimecolumns)
                        {
                         

                            if ((GridView1.Columns[c].HeaderText == datetimecolumn))
                            {                                
                                flagb = 1;
                            }
                        }
                        if (!(flag == 1) && !(flaga == 1) && !(flagb == 1))
                    {
                       /// if (!(c == datecolumn))
                       /// {
                            poop[b - 1] = row.Cells[c].Value.ToString();
                            //poop[b - 1] = myValues.GetValue(a, b);
                       /// }
                      //  else
                       // {
                       //     string columnheader = GridView1.Columns[datecolumn].HeaderText.ToString();
                           // MessageBox.Show(columnheader);
                        //    string checking = row.Cells[c].Value.ToString();
                         //   if (!(checking == "") && !(checking == "GETDATE()")&& columnheader.Contains("LAST_UPD_DTM"))
                         //   {
                         //       poop[b - 1] = "\"" + row.Cells[c].Value.ToString() + "\"";
                         //   }
                         //   else
                         //   {
                          //      poop[b - 1] = row.Cells[c].Value.ToString();
                          //  }
                       // }
                    }
                    else
                        {
                            if (flag == 1)
                            {
                                poop[b - 1] = string.Format("{0:F0}", (double)row.Cells[c].Value);
                            }
                            if (flaga == 1)
                            {
                                poop[b - 1] = string.Format("{0:T}", (DateTime)row.Cells[c].Value);
                            }
                            if (flagb == 1)
                            {                               
                                poop[b - 1] = string.Format("{0:d}", (DateTime)row.Cells[c].Value);
                            }
                    }
                   }
                   catch (Exception ex)
                   {
                        poop[b - 1] = "";
                        check = 1;
                   }
                }
                //toolStripProgressBar2.Value = 60;
                using (System.IO.StreamWriter file = new System.IO.StreamWriter((path), true))
                {
                    string commandText;
                    commandText = "INSERT INTO " +cddb.Text+".."+ s1 + field_names+"\r\n" +
                        "VALUES"+ "\r\n" +"(";                    
                    string checkcond = checkstring;
                 
                    foreach (string line in poop)
                    {
                       
                        string text = "";

                        if (checkcond.Length > 1)
                        {
                            text = checkcond.Remove(1);
                        }
                        else
                        {
                            text = checkcond;
                        }

                        if (text == "Y")
                        {
                            if (line == "NULL" || line == "null" || line == "(null)" || line == "")
                            {
                                commandText += "0,";
                            }
                            else
                            {
                                commandText += line + ",";
                            }
                        }
                        if (text == "N")
                        {
                            if (line == "NULL" || line == "null" || line == "(null)")
                            {
                                string line2 = "";
                                commandText += "\"" + line2 + "\",";
                            }
                            else
                            {
                                commandText += "\"" + line + "\",";
                            }
                        }
                        checkcond = checkcond.Remove(0, 1);
                       
                    }

                    commandText = commandText.Remove(commandText.Length - 1);
                    commandText += ")";
                    file.WriteLine(commandText);
                    //file.WriteLine("GO");
                     }
               
            }
            using (System.IO.StreamWriter file = new System.IO.StreamWriter((path), true))
            {
                file.WriteLine("PRINT 'END : Inserting into table " + s1 + "'");
                file.WriteLine("GO");
            }
            //toolStripProgressBar2.Value = 100;
            button3.Enabled = true;
            sw.Stop();
            lbltime.Text = "Time Consumed : " + sw.Elapsed.TotalSeconds + "sec.";
            lblstatus.Text = "Ready";
            lblprocessstatus.Text = "Script Created Successfully!";
            generatetime = Convert.ToDouble(sw.Elapsed.TotalSeconds);
            generatetime = generatetime + importtime;


           string  reportpath = @"c:\\Insert_Scripts\\" + s1 + currdate + "\\" + s1 + "_Summary_Report" + ".txt";
            //FileStream fs = null;
            if (!File.Exists(reportpath))
            {
                using (fs = File.Create(reportpath))
                {

                }
            }
            attachment1 = reportpath;
            File.WriteAllText(reportpath, "");
            using (System.IO.StreamWriter file = new System.IO.StreamWriter((reportpath), true))
            {
                file.WriteLine("/****************************Start Of Report********************************");
                string scriptname = "";
                scriptname = " Insert Script Name             : " + s1 + "_insert" + " ";
                             
                if (scriptname.Length < 80)
                {
                    scriptname = scriptname.Remove(scriptname.Length - 1);

                }

                while (scriptname.Length < 80)
                {
                    scriptname += " ";
                }
                scriptname = scriptname.Remove(scriptname.Length - 2);
                scriptname += " ";
                file.WriteLine(scriptname);
                file.WriteLine(" Table Name                     : " + ccb.Text);
                int Index1000;
                Index1000 = lbltotal.Text.LastIndexOf(":");
                string total = lbltotal.Text.Substring((Index1000 + 1), ((lbltotal.Text.Length) - Index1000 - 1));
                Index1000 = lblduplicate.Text.LastIndexOf(":");
                string duptotal = lblduplicate.Text.Substring((Index1000 + 1), ((lblduplicate.Text.Length) - Index1000 - 1));
                Index1000 = lbloriginal.Text.LastIndexOf(":");
                string orgtotal = lbloriginal.Text.Substring((Index1000 + 1), ((lbloriginal.Text.Length) - Index1000 - 1));
                file.WriteLine(" Total No. Of Records           :" + total);
                file.WriteLine(" Total No. Of Duplicate Records :" + duptotal);
                file.WriteLine(" Total No. Of Original Records  :" + orgtotal);
                file.WriteLine(" Total No. Of Columns           : " + GridView1.ColumnCount.ToString());
                if (!(invalidcolumns == ""))
                {
                file.WriteLine(" Invalid Columns                : " + invalidcolumns);
                }
                file.WriteLine(" Total Records in Script        : " + GridView1.RowCount.ToString());
                file.WriteLine(" Total Execution Time           : " + generatetime.ToString() + "sec.");
                file.WriteLine("                                                                             ");
                file.WriteLine("       Autogenerated Summary Report by Insert Script Generator Tool.         ");                
                file.WriteLine("******************************End of Report********************************/");

            }

            Process.Start(path);
            
        }

        private void Close_Click(object sender, EventArgs e)
        {
            Form_Close();

            
        }


        private void fileSelect_SelectedIndexChanged(object sender, EventArgs e)
        {
            cddb.Enabled = true;
        }


        private void browse_Click(object sender, EventArgs e)
        {
            //GridView1.items
            checkBox3.Enabled = false;
            checkBox2.Enabled = false;
            checkBox1.Enabled = false;
            toolStripProgressBar2.Visible = false;
            lblstatus.Text = "Ready";
            lblprocessstatus.Text = "     ";
            lbltotal.Text = "     ";
            lblduplicate.Text = "     ";
            lbloriginal.Text = "     ";
            lblcolumns.Text = "     ";
            lbltime.Text = "     ";
            sheetno = 0;
            Import.Enabled = false;
            txtfilepath.Clear();
            filepath = "Please Select an Input file";
            GridView1.DataSource = null;
            Import.Text = "Import Data";
            script.Enabled = false;
            button3.Enabled = false;
            comboBox1.Items.Clear();            
           // cddb.Items.Clear();
            ccb.Items.Clear();
            comboBox1.Text = "";
            ccb.Text="";
            cddb.Text="";
            comboBox1.Enabled = false;
            cddb.Enabled = false;
            ccb.Enabled = false;
            OpenFileDialog fDialog = new OpenFileDialog();
            fDialog.Title = "Open Layout File";
            //fDialog.Filter = "Excel/Csv Files(*.xls,*.xlsx,*.csv)|*.xls;*.xlsx;*.csv";
            fDialog.Filter = "Excel Files(*.xls,*.xlsx)|*.xls;*.xlsx";
            fDialog.InitialDirectory = @"C:\";
            if (fDialog.ShowDialog() == DialogResult.OK)
            {
                filepath = fDialog.FileName.ToString();
                //MessageBox.Show(filepath);
            }
            fDialog.AddExtension = true;
            txtfilepath.Text = filepath;
            if ((txtfilepath.Text.Contains("xlsx")) || (txtfilepath.Text.Contains("xls")) || (txtfilepath.Text.Contains("csv")))
            {                
                Import.Enabled = true;

                Microsoft.Office.Interop.Excel.Application xlApp;
                Microsoft.Office.Interop.Excel.Workbook xlWorkBook;
                Microsoft.Office.Interop.Excel.Worksheet xlWorkSheet;
                var missing = System.Reflection.Missing.Value;
                xlApp = new Microsoft.Office.Interop.Excel.Application();

                xlWorkBook = xlApp.Workbooks.Open(filepath, false, true, missing, missing, missing, true, Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, '\t', false, false, 0, false, true, 0);
                sheet_count  = xlWorkBook.Sheets.Count;
                int i = 0;
                int j = 0;
                blanks = "";
                foreach (Worksheet worksheet in xlWorkBook.Worksheets) 
                {


                    if(i<sheet_count)
                    {   
                         xlWorkSheet = (Microsoft.Office.Interop.Excel.Worksheet)xlWorkBook.Worksheets.get_Item(i+1);
                         Excel.Range xlRange = xlWorkSheet.UsedRange;
                         int row;
                         int col;
	                     row = xlWorkSheet.UsedRange.Rows.Count; //xlWorkSheet is Excel.Worksheet object
                         col = xlWorkSheet.UsedRange.Columns.Count;          
                         string value = Convert.ToString((xlRange.Cells[1, 1] as Excel.Range).Value2); //range is Excel.Range object
                         
                         if (row == 1 && col == 1 && value == "")
                         {
                             blanks += worksheet.Name + "\n";

                         }
                         else
                         {
                             ipname[i] = worksheet.Name;
                             j++;
                         }
                         i++;
                     }

                }
                if (!(j == 0))
                {
                    comboBox1.Enabled = true;
                    comboBox1.Text = "----------Select Worksheet----------";
                    for (int a = 0; a < j; a++)
                    {
                        comboBox1.Items.Add(ipname[a]);

                        comboBox1.MaxDropDownItems = 10;
                    }
                }
                if (!(blanks == ""))
                {
                    string textmsg = "Following Sheet(s) are Empty :" + "\n" + blanks;
                    MessageBox.Show(textmsg, "Empty Sheets Detected!");
                }
                xlWorkBook.Close(true, missing, missing);
                xlApp.Quit();
            }
            else
            {
                MessageBox.Show("Please select a Valid Input File", "Error Message");

                browse.Focus();
            }

        }

        private void duprowdelete()
        {
            Microsoft.Office.Interop.Excel.Application xlApp;
            Microsoft.Office.Interop.Excel.Workbook xlWorkBook;
            Microsoft.Office.Interop.Excel.Worksheet xlWorkSheet;
            var missing = System.Reflection.Missing.Value;
            xlApp = new Microsoft.Office.Interop.Excel.Application();
            xlWorkBook = xlApp.Workbooks.Add(missing);
            xlWorkSheet = (Microsoft.Office.Interop.Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);
            //field_names = "(";
            foreach (DataGridViewColumn col in GridView1.Columns)
            {
                xlWorkSheet.Cells[1, col.Index + 1] = col.HeaderText;

            }
            int i = 1;
            foreach(int no in duprowno)
            {
                DataGridViewRow row = GridView1.Rows[no];
                for (int j = 0; j < row.Cells.Count; j++)
                {
                    xlApp.Cells[i + 1, j + 1] = row.Cells[j].Value.ToString();
                }
                i++;
            }
            

            if (!Directory.Exists(@"C:\" + "Insert_Scripts\\" + s1 + currdate))
            {
                Directory.CreateDirectory(@"C:\" + "Insert_Scripts\\" + s1 + currdate);
            }
            int Index100;
            Index100 = filepath.LastIndexOf("\\");
            string filename = filepath.Substring((Index100 + 1), ((filepath.Length) - Index100 - 1));
            filename = @"C:\" + "Insert_Scripts\\" + s1 + currdate + "\\Duplicate_" + filename +".xls";
            xlWorkBook.SaveAs(filename, Excel.XlFileFormat.xlWorkbookNormal, missing, missing, missing, missing, Excel.XlSaveAsAccessMode.xlExclusive, missing, missing, missing, missing, missing);
            xlApp.ActiveWorkbook.Saved = true;
            xlApp.Quit();
            attachment2 = filename;
            for (int j = 0; j < GridView1.Rows.Count; j++)
            {

                string a = GridView1.Rows[j].DefaultCellStyle.BackColor.ToString();

                if ((a == "Color[Yellow]") || (a == "Color [Yellow]"))
                {
                    DataGridViewRow row = GridView1.Rows[j];
                    GridView1.Rows.Remove(row);
                    j--;
                }
                else
                {
                    GridView1.Rows[j].DefaultCellStyle.BackColor = Color.White;
                    
                }
                
            }

            MessageBox.Show(duplicaterecords.ToString() + " Duplicate Records Deleted.", "Duplicate Records");
            if (checkBox2.Enabled == false)
            {
                script.Enabled = true;
            }
            //GridView1.DefaultCellStyle.BackColor = Color.Turquoise;
            GridView1.Refresh();
            
        }


        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int i = 0;

            for (i = 0; i < sheet_count; i++)
            {
                if (comboBox1.Text == ipname[i])
                {
                    sheetname = comboBox1.Text;
                    sheetno = i+1;
                }
                

            }
            cddb.Enabled = true;
            cddb.Text = "---------Select Database---------";
        }
        private void dupcolumndelete()
        {
            int i = 0;
            int a = 0;
            
            foreach (DataGridViewColumn col in GridView1.Columns)
            {
                //MessageBox.Show(col.HeaderText);
              //  MessageBox.Show(delete_column);
                
                if (delete_column.Contains(col.HeaderText))
                {
                    deletecolumn[i] = col.HeaderText;
                   // MessageBox.Show(col.HeaderText);
                    i++;
                    a++;
                }
  

            }

            for (i = 0; i < a; i++)
            {
                GridView1.Columns.Remove(deletecolumn[i]);
            }
            if (checkBox1.Enabled == false)
            {
                script.Enabled = true;
            }
            script.Focus();
            lblcolumns.Text = GridView1.ColumnCount.ToString() + " Columns";
            field_names = "";
            field_names = "(";
            foreach (DataGridViewColumn col in GridView1.Columns)
            {
                field_names += col.HeaderText + ",";

            }
            field_names = field_names.Remove(field_names.Length - 1);
            field_names += ")";  

        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                string FROM = "";
                FROM = UserPrincipal.Current.EmailAddress;

                Outlook.Application oApp = new Outlook.Application();
                Outlook.MailItem oMsg = (Outlook.MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);
                //oMailItem.To = address;
                // body, bcc etc...
                //oMsg.BCC = FROM;
                oMsg.Subject = "Insert Script Generator Files";

                oMsg.HTMLBody = "<font face='calibri' >Hi,<br />"
        + " <br />" +
            "<font color='light blue' face='calibri'>Please find the attached Files.</font" + " <br />"
             + " <br />" +
             " <br />" +
            "<font color='green' face='calibri' size=2 ><b>|| Autogenerated E-mail By Insert Script Generator Tool ||</b>";
                int pos = (int)oMsg.Body.Length + 1;
                int attachType = (int)Microsoft.Office.Interop.Outlook.OlAttachmentType.olByValue;


                Outlook.Attachment oAttach = oMsg.Attachments.Add(attachment, attachType, pos, "script");
                if (!(attachment1 == ""))
                {
                    oAttach = oMsg.Attachments.Add(attachment1, attachType, pos, "Report");
                }
                if (!(attachment2 == ""))
                {
                    oAttach = oMsg.Attachments.Add(attachment2, attachType, pos, "Excel File");
                }
                oMsg.Display(true);
            }
            catch (Exception ex)
            {
                MessageBox.Show("An Error Occured While Executing: "+ex, "Error Message");
            }

        }

        private void ccb_SelectedIndexChanged(object sender, EventArgs e)
        {
            Import.Enabled = true;
        }


        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if ((checkBox3.Checked == true) && (checkBox2.Enabled == false))
            {
                checkBox1.Enabled = false;
                script.Enabled = true;
            }
            else
            {
                if ((checkBox3.Checked == true) && (checkBox2.Enabled == true))
                {
                    checkBox1.Enabled = false;
                    script.Enabled = false;
                }
            }
            if (checkBox3.Checked == false)
            {
                checkBox1.Enabled = true;
                script.Enabled = false; 
            }
        }

        private void checkBox1_Click(object sender, EventArgs e)
        {
            checkBox1.Enabled = false;
            checkBox3.Enabled = false;
            duprowdelete();
        }

        private void checkBox2_Click(object sender, EventArgs e)
        {
            
            checkBox2.Enabled = false;            
            dupcolumndelete();
        }

        private void label11_Click(object sender, EventArgs e)
        {

        }



    



    }

}
