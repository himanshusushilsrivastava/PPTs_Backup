﻿namespace Insert_Script_Generator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.tbuser = new System.Windows.Forms.TextBox();
            this.tbPwd = new System.Windows.Forms.TextBox();
            this.env = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.Exit = new System.Windows.Forms.Button();
            this.Authen = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.ddlEnvironment = new System.Windows.Forms.ListBox();
            this.lblFldr = new System.Windows.Forms.Label();
            this.lblDrive = new System.Windows.Forms.Label();
            this.drive = new Microsoft.VisualBasic.Compatibility.VB6.DriveListBox();
            this.dir = new Microsoft.VisualBasic.Compatibility.VB6.DirListBox();
            this.inifile = new Microsoft.VisualBasic.Compatibility.VB6.FileListBox();
            this.label7 = new System.Windows.Forms.Label();
            this.file = new System.Windows.Forms.Label();
            this.Path = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.Path.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbuser
            // 
            this.tbuser.Location = new System.Drawing.Point(184, 16);
            this.tbuser.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tbuser.Name = "tbuser";
            this.tbuser.Size = new System.Drawing.Size(175, 23);
            this.tbuser.TabIndex = 2;
            // 
            // tbPwd
            // 
            this.tbPwd.Location = new System.Drawing.Point(184, 66);
            this.tbPwd.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tbPwd.Name = "tbPwd";
            this.tbPwd.PasswordChar = '*';
            this.tbPwd.Size = new System.Drawing.Size(175, 23);
            this.tbPwd.TabIndex = 3;
            // 
            // env
            // 
            this.env.AutoSize = true;
            this.env.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.env.Location = new System.Drawing.Point(373, 54);
            this.env.Name = "env";
            this.env.Size = new System.Drawing.Size(89, 16);
            this.env.TabIndex = 4;
            this.env.Text = "Environment";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(33, 19);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 16);
            this.label3.TabIndex = 6;
            this.label3.Text = "Username";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(33, 66);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(71, 16);
            this.label4.TabIndex = 7;
            this.label4.Text = "Password";
            // 
            // Exit
            // 
            this.Exit.Location = new System.Drawing.Point(199, 119);
            this.Exit.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Exit.Name = "Exit";
            this.Exit.Size = new System.Drawing.Size(146, 28);
            this.Exit.TabIndex = 10;
            this.Exit.Text = "Exit";
            this.Exit.UseVisualStyleBackColor = true;
            this.Exit.Click += new System.EventHandler(this.Exit_Click);
            // 
            // Authen
            // 
            this.Authen.Location = new System.Drawing.Point(36, 119);
            this.Authen.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Authen.Name = "Authen";
            this.Authen.Size = new System.Drawing.Size(134, 28);
            this.Authen.TabIndex = 4;
            this.Authen.Text = "Login";
            this.Authen.UseVisualStyleBackColor = true;
            this.Authen.Click += new System.EventHandler(this.button2_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Tahoma", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(472, 9);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(122, 24);
            this.label6.TabIndex = 13;
            this.label6.Text = "Login - Form";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.tbuser);
            this.panel1.Controls.Add(this.Authen);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.tbPwd);
            this.panel1.Controls.Add(this.Exit);
            this.panel1.Location = new System.Drawing.Point(353, 181);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(364, 162);
            this.panel1.TabIndex = 4;
            // 
            // ddlEnvironment
            // 
            this.ddlEnvironment.AllowDrop = true;
            this.ddlEnvironment.FormattingEnabled = true;
            this.ddlEnvironment.ItemHeight = 16;
            this.ddlEnvironment.Location = new System.Drawing.Point(531, 54);
            this.ddlEnvironment.Name = "ddlEnvironment";
            this.ddlEnvironment.Size = new System.Drawing.Size(186, 116);
            this.ddlEnvironment.TabIndex = 1;
            this.ddlEnvironment.SelectedIndexChanged += new System.EventHandler(this.ddlEnvironment_SelectedIndexChanged);
            // 
            // lblFldr
            // 
            this.lblFldr.AutoSize = true;
            this.lblFldr.Location = new System.Drawing.Point(12, 116);
            this.lblFldr.Name = "lblFldr";
            this.lblFldr.Size = new System.Drawing.Size(91, 16);
            this.lblFldr.TabIndex = 18;
            this.lblFldr.Text = "Select Folder";
            // 
            // lblDrive
            // 
            this.lblDrive.AutoSize = true;
            this.lblDrive.Location = new System.Drawing.Point(12, 57);
            this.lblDrive.Name = "lblDrive";
            this.lblDrive.Size = new System.Drawing.Size(86, 16);
            this.lblDrive.TabIndex = 15;
            this.lblDrive.Text = "Select Drive";
            // 
            // drive
            // 
            this.drive.FormattingEnabled = true;
            this.drive.Location = new System.Drawing.Point(126, 57);
            this.drive.Name = "drive";
            this.drive.Size = new System.Drawing.Size(161, 24);
            this.drive.TabIndex = 11;
            this.drive.SelectedIndexChanged += new System.EventHandler(this.driveSelect_SelectedIndexChanged);
            // 
            // dir
            // 
            this.dir.FormattingEnabled = true;
            this.dir.IntegralHeight = false;
            this.dir.Location = new System.Drawing.Point(126, 116);
            this.dir.Name = "dir";
            this.dir.Size = new System.Drawing.Size(161, 112);
            this.dir.TabIndex = 12;
            this.dir.SelectedIndexChanged += new System.EventHandler(this.dirSelect_SelectedIndexChanged);
            // 
            // inifile
            // 
            this.inifile.FormattingEnabled = true;
            this.inifile.Location = new System.Drawing.Point(126, 255);
            this.inifile.Name = "inifile";
            this.inifile.Pattern = "*.*";
            this.inifile.Size = new System.Drawing.Size(161, 52);
            this.inifile.TabIndex = 13;
            this.inifile.SelectedIndexChanged += new System.EventHandler(this.fileSelect_SelectedIndexChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(3, 18);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(298, 13);
            this.label7.TabIndex = 22;
            this.label7.Text = "Select the Sybase INI File to Load the Environments";
            // 
            // file
            // 
            this.file.AutoSize = true;
            this.file.Location = new System.Drawing.Point(12, 255);
            this.file.Name = "file";
            this.file.Size = new System.Drawing.Size(72, 16);
            this.file.TabIndex = 23;
            this.file.Text = "Select File";
            // 
            // Path
            // 
            this.Path.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Path.Controls.Add(this.file);
            this.Path.Controls.Add(this.label7);
            this.Path.Controls.Add(this.inifile);
            this.Path.Controls.Add(this.dir);
            this.Path.Controls.Add(this.drive);
            this.Path.Controls.Add(this.lblDrive);
            this.Path.Controls.Add(this.lblFldr);
            this.Path.Location = new System.Drawing.Point(16, 14);
            this.Path.Name = "Path";
            this.Path.Size = new System.Drawing.Size(302, 329);
            this.Path.TabIndex = 20;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(731, 359);
            this.Controls.Add(this.ddlEnvironment);
            this.Controls.Add(this.Path);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.env);
            this.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Location = new System.Drawing.Point(100, 50);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Configuration Script Generator";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.Path.ResumeLayout(false);
            this.Path.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbuser;
        private System.Windows.Forms.TextBox tbPwd;
        private System.Windows.Forms.Label env;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button Exit;
        private System.Windows.Forms.Button Authen;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ListBox ddlEnvironment;
        private System.Windows.Forms.Label lblFldr;
        private System.Windows.Forms.Label lblDrive;
        private Microsoft.VisualBasic.Compatibility.VB6.DriveListBox drive;
        private Microsoft.VisualBasic.Compatibility.VB6.DirListBox dir;
        private Microsoft.VisualBasic.Compatibility.VB6.FileListBox inifile;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label file;
        private System.Windows.Forms.Panel Path;
    }
}

